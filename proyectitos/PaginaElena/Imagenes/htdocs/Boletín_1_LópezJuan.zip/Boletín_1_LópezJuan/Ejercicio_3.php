<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 3</title>
</head>
<body>
    <?php
    $numero1 = 2;
    $numero2 = 4;
    echo "<h1> LA SUMA DE 2 Y 4 ES ",($numero1 + $numero2),"</h1>";
    ?>
</body>
</html>