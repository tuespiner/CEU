<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 1</title>
</head>
<body>
    <?php
    $nombre = "Juan";
    $apellido1 = "López";
    $apellido2 = "Carmona";
    $curso = "2ºDAW";
    $dni = '<img src="Imagenes/Spanish_ID_card_(front_side).webp.png">';
    echo "<p>",$nombre," ",$apellido1," ",$apellido2,"</p><br>",$dni;
    ?>
</body>
</html>