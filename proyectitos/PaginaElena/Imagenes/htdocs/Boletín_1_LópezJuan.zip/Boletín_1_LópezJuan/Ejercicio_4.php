<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 4</title>
</head>
<body>
    <?php
    $numero1 = 10;
    $numero2 = 7;
    $suma = $numero1 + $numero2;
    $resta = $numero1 - $numero2;
    $multiplicacion = $numero1 * $numero2;
    $division = $numero1 / $numero2;
    $modulo = $numero1 % $numero2;
    echo "<p>",$suma,"</p>";
    echo "<p>",$resta,"</p>";
    echo "<p>",$multiplicacion,"</p>";
    echo "<p>",$division,"</p>";
    echo "<p>",$modulo,"</p>";
    ?>
</body>
</html>