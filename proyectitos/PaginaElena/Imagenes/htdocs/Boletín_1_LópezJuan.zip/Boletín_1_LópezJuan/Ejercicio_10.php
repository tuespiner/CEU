<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 10</title>
</head>
<body>
    <?php
    $tempArray = array("primero" =>16, "segundo" => 15, "tercero" => 17, "cuarto" => 15, "quinto" => 16);
    $temperatura = $tempArray["cuarto"];
    echo "La temperatura de Málaga el cuarto día es de ",$temperatura, " Cº";
    ?>
</body>
</html>