<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 5</title>
</head>
<body>
<?php
    $numero = 8;
    $numero = $numero + 2;
    echo "<p>",$numero,"</p>";
    $numero = $numero - 2;
    echo "<p>",$numero,"</p>";
    $numero = $numero * 5;
    echo "<p>",$numero,"</p>";
    $numero = $numero / 3;
    echo "<p>",$numero,"</p>";
    $numero = $numero+=1;
    echo "<p>",$numero,"</p>";
    $numero = $numero-=1;
    echo "<p>",$numero,"</p>";
    ?>
</body>
</html>