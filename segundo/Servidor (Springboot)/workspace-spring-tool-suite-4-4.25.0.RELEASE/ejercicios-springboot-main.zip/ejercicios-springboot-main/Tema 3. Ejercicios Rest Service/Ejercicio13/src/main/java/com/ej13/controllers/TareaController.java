package com.ej13.controllers;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.ej13.model.Tarea;

@RestController
@RequestMapping("/tareas")
public class TareaController {

    private List<Tarea> listaTareas;

    public TareaController() {
    	
        listaTareas = new ArrayList<>();
        listaTareas.add(new Tarea(1, "Comprar víveres", "Comprar leche, pan y huevos", LocalDate.of(2024, 7, 30), "PENDIENTE"));
        listaTareas.add(new Tarea(2, "Enviar informe", "Enviar informe trimestral a finanzas", LocalDate.of(2024, 7, 25), "EN_PROCESO"));
        listaTareas.add(new Tarea(3, "Llamar al médico", "Programar cita para revisión anual", LocalDate.of(2024, 8, 5), "PENDIENTE"));
        listaTareas.add(new Tarea(4, "Actualizar software", "Actualizar el software del servidor", LocalDate.of(2024, 7, 20), "COMPLETA"));
    }

    // Obtener todas las tareas
    @GetMapping
    public ResponseEntity<List<Tarea>> obtenerTodasLasTareas() {
    	return ResponseEntity.ok(listaTareas);
    }

    // Obtener tarea por ID
    @GetMapping("/{id}")
    public ResponseEntity<Tarea> obtenerTareaPorId(@PathVariable Integer id) {
        for (Tarea tarea : listaTareas) {
            if (tarea.getId().equals(id)) {
            	return ResponseEntity.ok(tarea);
            }
        }
        return ResponseEntity.notFound().build();
    }

    // Crear nueva tarea
    @PostMapping
    public ResponseEntity<Tarea> crearTarea(@RequestBody Tarea tarea) {
        listaTareas.add(tarea);
        return ResponseEntity.ok(tarea);
    }

    // Actualizar tarea completa
    @PutMapping()
    public ResponseEntity<Tarea> actualizarTarea(@RequestBody Tarea tareaActualizada) {
        for (int i = 0; i < listaTareas.size(); i++) {
            Tarea tarea = listaTareas.get(i);
            if (tarea.getId().equals(tareaActualizada.getId())) {
                tarea.setTitulo(tareaActualizada.getTitulo());
                tarea.setDescripcion(tareaActualizada.getDescripcion());
                tarea.setFechaVencimiento(tareaActualizada.getFechaVencimiento());
                tarea.setEstado(tareaActualizada.getEstado());
                return ResponseEntity.noContent().build();
            }
        }
        return ResponseEntity.notFound().build();
    }

    // Actualizar parcialmente una tarea
    @PatchMapping()
    public ResponseEntity<Tarea> actualizarParcialmenteTarea( @RequestBody Tarea tareaActualizada) {
        for (Tarea tarea : listaTareas) {
        	if (tarea.getId().equals(tareaActualizada.getId())) {
                if (tareaActualizada.getTitulo() != null) {
                    tarea.setTitulo(tareaActualizada.getTitulo());
                }
                if (tareaActualizada.getDescripcion() != null) {
                    tarea.setDescripcion(tareaActualizada.getDescripcion());
                }
                if (tareaActualizada.getFechaVencimiento() != null) {
                    tarea.setFechaVencimiento(tareaActualizada.getFechaVencimiento());
                }
                if (tareaActualizada.getEstado() != null) {
                    tarea.setEstado(tareaActualizada.getEstado());
                }
                return ResponseEntity.noContent().build();
            }
        }
        return ResponseEntity.notFound().build();
    }

    // Eliminar tarea
    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminarTarea(@PathVariable Integer id) {
        
    	Iterator<Tarea> iterador = listaTareas.iterator();
		while (iterador.hasNext()) {
			Tarea tarea = iterador.next();
			if (tarea.getId().equals(id)) {
				iterador.remove();
				return ResponseEntity.noContent().build();
			}
		}

		return ResponseEntity.notFound().build();
    	
    }

    // Obtener tareas por estado
    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<Tarea>> obtenerTareasPorEstado(@PathVariable String estado) {
        List<Tarea> tareasPorEstado = new ArrayList<>();
        for (Tarea tarea : listaTareas) {
            if (estado.equalsIgnoreCase(tarea.getEstado())) {
            	System.out.println(estado);
                tareasPorEstado.add(tarea);
            }
        }
        return tareasPorEstado.isEmpty() ?  ResponseEntity.notFound().build(): ResponseEntity.ok(tareasPorEstado);
    }
    
    @GetMapping("/proximas/{dias}")
    public ResponseEntity<List<Tarea>> obtenerTareasProximasAVencer(@PathVariable int dias) {
        LocalDate fechaLimite = LocalDate.now().plusDays(dias);
        List<Tarea> proximasTareas = new ArrayList<>();
        for (Tarea tarea : listaTareas) {
            if (tarea.getFechaVencimiento().isBefore(fechaLimite) && tarea.getFechaVencimiento().isAfter(LocalDate.now().minusDays(1))) {
                proximasTareas.add(tarea);
            }
        }
        return proximasTareas.isEmpty() ? ResponseEntity.notFound().build(): ResponseEntity.ok(proximasTareas);
    }
    
    @GetMapping("/contar-estado")
    public ResponseEntity<Map<String, Integer>> contarTareasPorEstado() {
        Map<String, Integer> conteoPorEstado = new HashMap<>();
        for (Tarea tarea : listaTareas) {
            conteoPorEstado.put(tarea.getEstado(), conteoPorEstado.getOrDefault(tarea.getEstado(), 0) + 1);
        }
        return  ResponseEntity.ok(conteoPorEstado);
    }
    
    @GetMapping("/buscar/{palabraClave}")
    public ResponseEntity<List<Tarea>> obtenerTareasPorPalabraClave(@PathVariable String palabraClave) {
        List<Tarea> tareasConPalabraClave = new ArrayList<>();
        for (Tarea tarea : listaTareas) {
            if (tarea.getDescripcion() != null && tarea.getDescripcion().toLowerCase().contains(palabraClave.toLowerCase())) {
                tareasConPalabraClave.add(tarea);
            }
        }
        return tareasConPalabraClave.isEmpty() ? ResponseEntity.notFound().build(): ResponseEntity.ok(tareasConPalabraClave);
    }
    
 // Marcar tareas vencidas como completas
    @PatchMapping("/marcar-completadas")
    public ResponseEntity<String> marcarTareasCompletadas() {
        boolean algunaModificada = false;
        for (Tarea tarea : listaTareas) {
            if (tarea.getFechaVencimiento().isBefore(LocalDate.now()) && !tarea.getEstado().equalsIgnoreCase("COMPLETA")) {
                tarea.setEstado("COMPLETA");
                algunaModificada = true;
            }
        }
        return algunaModificada ? ResponseEntity.noContent().build(): ResponseEntity.notFound().build();
    }
    
}