package com.ej12.controllers;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ej12.model.Libro;

@RestController
@RequestMapping("/libros")
public class LibroController {

	private List<Libro> libros = new ArrayList<>();

	LibroController() {

		libros.add(new Libro(1, "El Quijote", "Miguel de Cervantes", "Editorial A", "123456789", 1605,
				List.of("Novela", "Clásico")));
		libros.add(new Libro(2, "Cien Años de Soledad", "Gabriel García Márquez", "Editorial B", "987654321", 1967,
				List.of("Realismo mágico", "Novela")));
		libros.add(new Libro(3, "1984", "George Orwell", "Editorial C", "1122334455", 1949,
				List.of("Distopía", "Política")));
		libros.add(new Libro(4, "El Señor de los Anillos", "J.R.R. Tolkien", "Editorial D", "6677889900", 1954,
				List.of("Fantasía", "Aventura")));
		libros.add(new Libro(5, "La Gitanilla", "Miguel de Cervantes", "Editorial D", "6677889900", 1954,
				List.of("Novela", "Aventura")));

	}

	@GetMapping
	public ResponseEntity<List<Libro>> getLibros() {
		return ResponseEntity.ok(libros);
	}

	@GetMapping("/{titulo}")
	public ResponseEntity<Libro> getLibro(@PathVariable String titulo) { // Equivalente a GET /libros/{titulo}
		for (Libro libro : libros) {

			if (libro.getTitulo().equalsIgnoreCase(titulo)) {
				return ResponseEntity.ok(libro);
			}
		}
		return ResponseEntity.notFound().build();
	}

	@GetMapping("/novelas")
	public ResponseEntity<List<Libro>> obtenerNovelas() {
		List<Libro> novelas = new ArrayList<>();
		for (Libro libro : libros) {
			if (libro.getGeneros().contains("Novela")) {
				novelas.add(libro);
			}
		}

		if (novelas.isEmpty())
			return ResponseEntity.notFound().build();
		else
			return ResponseEntity.ok(novelas);
	}

	@GetMapping("/porGenero/{genero}")
	public ResponseEntity<List<Libro>> obtenerPorGenero(@PathVariable String genero) {
		List<Libro> librosPorGenero = new ArrayList<>();
		for (Libro libro : libros) {
			if (libro.getGeneros().contains(genero)) {
				librosPorGenero.add(libro);
			}
		}
		if (librosPorGenero.isEmpty())
			return ResponseEntity.notFound().build();
		else
			return ResponseEntity.ok(librosPorGenero);
	}

	@PostMapping
	public ResponseEntity<Libro> postLibro(@RequestBody Libro libro) {
		libros.add(libro);
		return ResponseEntity.ok(libro);
	}

	@PutMapping
	public ResponseEntity<Libro> putLibro(@RequestBody Libro libroActualizado) {

		for (Libro libro : libros) {

			if (libro.getId().equals(libroActualizado.getId())) {

				libro.setTitulo(libroActualizado.getTitulo());
				libro.setAutor(libroActualizado.getAutor());
				libro.setEditorial(libroActualizado.getEditorial());
				libro.setIsbn(libroActualizado.getIsbn());
				libro.setAñoPublicacion(libroActualizado.getAñoPublicacion());
				libro.setGeneros(libroActualizado.getGeneros());

				return ResponseEntity.noContent().build();
			}
		}
		return ResponseEntity.notFound().build();
	}

	@PatchMapping
	public ResponseEntity<Libro> patchLibro(@RequestBody Libro libroActualizado) {

		for (Libro libro : libros) {

			if (libro.getId().equals(libroActualizado.getId())) {

				if (libroActualizado.getTitulo() != null) {
					libro.setTitulo(libroActualizado.getTitulo());
				}
				if (libroActualizado.getAutor() != null) {
					libro.setAutor(libroActualizado.getAutor());
				}
				if (libroActualizado.getEditorial() != null) {
					libro.setEditorial(libroActualizado.getEditorial());
				}
				if (libroActualizado.getIsbn() != null) {
					libro.setIsbn(libroActualizado.getIsbn());
				}
				if (libroActualizado.getAñoPublicacion() != 0) {
					libro.setAñoPublicacion(libroActualizado.getAñoPublicacion());
				}
				if (libroActualizado.getGeneros() != null) {
					libro.setGeneros(libroActualizado.getGeneros());
				}

				return ResponseEntity.noContent().build();
			}
		}
		return ResponseEntity.notFound().build();
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Libro> deleteLibro(@PathVariable int id) {

		Iterator<Libro> iterador = libros.iterator();
		while (iterador.hasNext()) {
			Libro libro = iterador.next();
			if (libro.getId().equals(id)) {
				iterador.remove();
				return ResponseEntity.noContent().build();
			}
		}

		return ResponseEntity.notFound().build();
	}

	@GetMapping("/autores/con-mas-de/{numLibros}")
	public Map<String, Integer> obtenerAutoresConMasDeXLibros(@PathVariable int numLibros) {
		Map<String, Integer> conteoPorAutor = new HashMap<>();

		// Contar la cantidad de libros por autor
		for (Libro libro : libros) {
			String autor = libro.getAutor();
			conteoPorAutor.put(autor, conteoPorAutor.getOrDefault(autor, 0) + 1);
		}

		// Filtrar los autores que tienen más de `numLibros` libros
		Map<String, Integer> autoresFiltrados = new HashMap<>();
		
		Set<Entry<String, Integer>> pares =  conteoPorAutor.entrySet();
		for (Entry<String, Integer> par : pares) {
			if (par.getValue() > numLibros) {
				autoresFiltrados.put(par.getKey(), par.getValue());
			}
		}
		 return autoresFiltrados;
	}
}
