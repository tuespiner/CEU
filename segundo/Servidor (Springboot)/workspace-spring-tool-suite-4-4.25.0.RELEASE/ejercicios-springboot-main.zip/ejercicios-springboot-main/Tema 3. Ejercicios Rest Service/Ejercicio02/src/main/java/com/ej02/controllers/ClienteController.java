package com.ej02.controllers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ej02.model.Cliente;

@RestController
public class ClienteController {
	/*
	private List<Cliente> clientes = new ArrayList<>();
	
	public ClienteController(){
		
		Cliente c1 = new Cliente(123,"Pepe Lopez","plopez","clave123");
		Cliente c2 = new Cliente(456,"Luis Bel","lbel","clave456");
		Cliente c3 = new Cliente(789,"Rocío Perez", "rperez","clave789");
		Cliente c4 = new Cliente(234,"Juan García","jgarcia","clave234");
		clientes.add(c1);
		clientes.add(c2);
		clientes.add(c3);
		clientes.add(c4);		
		
	}
		
	@GetMapping("/clientes")
	public List<Cliente> getClientes(){
		return clientes;
	}	
	
	@GetMapping("/clientes/{username}")
	public Cliente getCliente (@PathVariable String username) {
		for (Cliente cliente : clientes) {
			if(cliente.getUsename().equalsIgnoreCase(username)) {
				return cliente;
			}
		}
		return null;
	}
	
	@PostMapping("/clientes")
	public Cliente postCliente(@RequestBody Cliente cliente) {
		clientes.add(cliente);
		return cliente;		
	}
	
	@PutMapping("/clientes")
	public Cliente putCliente(@RequestBody  Cliente modif) {
		for (Cliente cliente : clientes) {
			if(cliente.getId()==modif.getId()) {
				cliente.setNombre(modif.getNombre());
				cliente.setPassword(modif.getPassword());
				cliente.setUsename(modif.getUsename());
				
				return cliente;
			}
		}
		return null;
	}
	
	@DeleteMapping("/clientes/{id}")
	public Cliente deleteCliente(@PathVariable int id) {
		
		Iterator<Cliente> iterador = clientes.iterator();
        while (iterador.hasNext()) {
            Cliente cliente = iterador.next();
            if(cliente.getId()==id) {
                iterador.remove();
                return cliente;
            }
        }
		
		return null;		
	}
	
	@PatchMapping("/clientes")
	public Cliente patchCliente(@RequestBody  Cliente modif) {
		for (Cliente cliente : clientes) {
			if(cliente.getId()==modif.getId()) {
				
				if(modif.getNombre()!=null) {		
					System.out.println("nombre");
					cliente.setNombre(modif.getNombre());
				}
				
				if(modif.getPassword()!=null) {			
					System.out.println("pass");
					cliente.setPassword(modif.getPassword());
				}
				
				if(modif.getUsename()!=null) {
					System.out.println("user");
					cliente.setUsename(modif.getUsename());
				}
														
				return cliente;
			}
		}
		return null;
	}
	*/

}
