package com.ej11.controllers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ej11.model.Direccion;
import com.ej11.model.Student;

@RestController
@RequestMapping("/alumnos")
public class StudentResponseController {

	private List<Student> alumnos = new ArrayList<>();

	StudentResponseController() {

		alumnos.add(new Student(123, "Juan Pérez", "juanp@example.com", 20, "Matemáticas",
                new Direccion("Calle 1", "12345", "Ciudad A")));
		alumnos.add(new Student(223, "María Gómez", "mariag@example.com", 22, "Historia",
                new Direccion("Calle 2", "54321", "Ciudad B")));
		alumnos.add(new Student(334, "Carlos López", "carlosl@example.com", 21, "Física",
                new Direccion("Calle 3", "09876", "Ciudad C")));
		alumnos.add(new Student(444, "Ana Martínez", "anam@example.com", 23, "Química",
                new Direccion("Calle 4", "09876", "Ciudad B")));

	}

	@GetMapping	
	public ResponseEntity<List<Student>> getAlumnos() {		
		 return  ResponseEntity.ok(alumnos);
	}

	@GetMapping("/direcciones")
	public ResponseEntity<List<Direccion>> getDirecciones() {			
		
		List<Direccion> direcciones = new ArrayList<>();
        for (Student alumno : alumnos) {
            direcciones.add(alumno.getDireccion());
        }
                
		return  ResponseEntity.ok(direcciones);
	}
	
	@GetMapping("/direcciones/{codigoPostal}")
	public ResponseEntity<List<Direccion>> obtenerDireccionesPorCodigoPostal(@PathVariable String codigoPostal) {
	    List<Direccion> direcciones = new ArrayList<>();
	    for (Student alumno : alumnos) {
	        if (alumno.getDireccion().getCodigoPostal().equals(codigoPostal)) {
	            direcciones.add(alumno.getDireccion());
	        }
	    }
	    if (!direcciones.isEmpty())
	    	return ResponseEntity.ok(direcciones);
	    else
	    	return ResponseEntity.notFound().build();		
	}
	
	@GetMapping("/direcciones/contar/{ciudad}")
	public ResponseEntity<Integer> contarAlumnosPorCiudad(@PathVariable String ciudad) {
	    int count = 0;
	    for (Student alumno : alumnos) {
	        if (alumno.getDireccion().getCiudad().equalsIgnoreCase(ciudad)) {
	            count++;
	        }
	    }
	   
	    if(count==0)
	    	   return ResponseEntity.notFound().build();
	    else
	    	return ResponseEntity.ok(count);
	    
	}
	
	@GetMapping("/{email}")
	public ResponseEntity<Student> getAlumno(@PathVariable String email) {
		for (Student student : alumnos) {

			if (student.getEmail().equals(email)) {
				return ResponseEntity.ok(student);
			}
		}
		return ResponseEntity.notFound().build();		
	}

	@PostMapping
	public ResponseEntity<Student> postAlumno(@RequestBody Student alumno) {
		alumnos.add(alumno);
		return ResponseEntity.ok(alumno);
	}

	@PutMapping
	public ResponseEntity<Student> putAlumno(@RequestBody Student alumno) {

		for (Student student : alumnos) {

			if (student.getId().equals(alumno.getId())) {
				student.setCurso(alumno.getCurso());
				student.setEdad(alumno.getEdad());
				student.setEmail(alumno.getEmail());
				student.setNombre(alumno.getNombre());
				
				student.setDireccion(alumno.getDireccion()); // nueva linea
				
				return ResponseEntity.noContent().build();
			}
		}
		return ResponseEntity.notFound().build();
	}

	@PatchMapping
	public ResponseEntity<Student> patchAlumno(@RequestBody Student alumno) {

		for (Student student : alumnos) {

			if (student.getId().equals(alumno.getId())) {
				
				if(alumno.getCurso()!=null)
					student.setCurso(alumno.getCurso());
				if(alumno.getEdad()!=null)
					student.setEdad(alumno.getEdad());
				if(alumno.getEmail()!=null)
					student.setEmail(alumno.getEmail());
				if(alumno.getNombre()!=null)				
					student.setNombre(alumno.getNombre());
				if(alumno.getDireccion()!=null)				
					student.setDireccion(alumno.getDireccion()); //nueva linea
				
				return ResponseEntity.noContent().build();
			}
		}
		return ResponseEntity.notFound().build();
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Student> deleteCliente(@PathVariable int id) {
		
		Iterator<Student> iterador = alumnos.iterator();
        while (iterador.hasNext()) {
        	Student alumno = iterador.next();
            if(alumno.getId()==id) {
                iterador.remove();
            	return ResponseEntity.noContent().build();
            }
        }
		
        return ResponseEntity.notFound().build();	
	}
}
