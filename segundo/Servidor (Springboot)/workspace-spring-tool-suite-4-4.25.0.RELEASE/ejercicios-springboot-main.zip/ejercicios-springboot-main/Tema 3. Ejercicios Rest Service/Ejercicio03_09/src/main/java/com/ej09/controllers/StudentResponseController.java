package com.ej09.controllers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ej09.model.Student;

@RestController
@RequestMapping("/alumnos")
public class StudentResponseController {

	private List<Student> alumnos = new ArrayList<>();

	StudentResponseController() {

		Student s1 = new Student(123, "Pepe Lopez", "plopez@gmail.com", 20, "Servidor");
		Student s2 = new Student(456, "Luis Bel", "lbel@gmail.com", 21, "Cliente");
		Student s3 = new Student(789, "Rocío Perez", "rperez@gmail.com", 23, "Programación");
		Student s4 = new Student(234, "Juan García", "jgarcia@gmail.com", 22, "Base de Datos");

		alumnos.add(s1);
		alumnos.add(s2);
		alumnos.add(s3);
		alumnos.add(s4);

	}

	@GetMapping	
	public ResponseEntity<List<Student>> getAlumnos() {		
		 return  ResponseEntity.ok(alumnos);
	}

	@GetMapping("/{email}")
	public ResponseEntity<Student> getAlumno(@PathVariable String email) {
		for (Student student : alumnos) {

			if (student.getEmail().equals(email)) {
				return ResponseEntity.ok(student);
			}
		}
		return ResponseEntity.notFound().build();		
	}

	@PostMapping
	public ResponseEntity<Student> postAlumno(@RequestBody Student alumno) {

		alumnos.add(alumno);
		return ResponseEntity.ok(alumno);
	}

	@PutMapping
	public ResponseEntity<Student> putAlumno(@RequestBody Student alumno) {

		for (Student student : alumnos) {

			if (student.getId().equals(alumno.getId())) {
				student.setCurso(alumno.getCurso());
				student.setEdad(alumno.getEdad());
				student.setEmail(alumno.getEmail());
				student.setNombre(alumno.getNombre());
				
				return ResponseEntity.noContent().build();
			}
		}
		return ResponseEntity.notFound().build();
	}

	@PatchMapping
	public ResponseEntity<Student> patchAlumno(@RequestBody Student alumno) {

		for (Student student : alumnos) {

			if (student.getId().equals(alumno.getId())) {
				
				if(alumno.getCurso()!=null)
					student.setCurso(alumno.getCurso());
				if(alumno.getEdad()!=null)
					student.setEdad(alumno.getEdad());
				if(alumno.getEmail()!=null)
					student.setEmail(alumno.getEmail());
				if(alumno.getNombre()!=null)				
					student.setNombre(alumno.getNombre());
				
				return ResponseEntity.noContent().build();
			}
		}
		return ResponseEntity.notFound().build();
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Student> deleteCliente(@PathVariable int id) {
		
		Iterator<Student> iterador = alumnos.iterator();
        while (iterador.hasNext()) {
        	Student alumno = iterador.next();
            if(alumno.getId()==id) {
                iterador.remove();
            	return ResponseEntity.noContent().build();
            }
        }
		
        return ResponseEntity.notFound().build();	
	}
}
