package com.ej01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
