$(document).ready(function(){
    $('#cookiesButton').on('click', function(){
        $('#cookies').hide()
    })
})