import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { pais } from '../model/pais.model';

@Injectable({
  providedIn: 'root'
})
export class EuropaService {
  url: string = "https://www.restcountries.com/v3.1/"
  constructor(private http: HttpClient) { }

  getPaises(){
    return this.http.get<pais>(this.url+"region/europe")
  }
  getSpain(){
    return this.http.get<pais>(this.url+"name/spain")
  }
}
