import { TestBed } from '@angular/core/testing';

import { EuropaService } from './europa.service';

describe('EuropaService', () => {
  let service: EuropaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EuropaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
