import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { EuropaComponent } from './europa/europa.component';
import { SpainComponent } from './spain/spain.component';

export const routes: Routes = [
    {path:'', component:HomeComponent},
    {path:'europa', component:EuropaComponent},
    {path:'spain', component:SpainComponent},
    {path:'**', component:HomeComponent}
];
