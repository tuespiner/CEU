import { Component, OnInit } from '@angular/core';
import { EuropaService } from '../services/europa.service';
import { Observable } from 'rxjs';
import { pais } from '../model/pais.model';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms';

@Component({
  selector: 'app-europa',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './europa.component.html',
  styleUrl: './europa.component.css'
})
export class EuropaComponent implements OnInit{
  europaList$= new Observable<pais>();

  constructor(private service: EuropaService){}

  ngOnInit(): void {
    this.europaList$ = this.service.getPaises()
    console.log(this.europaList$)
  }

}
