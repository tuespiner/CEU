export interface pais{
    name: {
        common: string,
        official: string
    },
    unMember: boolean,
    capital: string[],
    flags: {
        png: string
    }
}