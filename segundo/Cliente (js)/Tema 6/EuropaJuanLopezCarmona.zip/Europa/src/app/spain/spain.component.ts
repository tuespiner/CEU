import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { pais } from '../model/pais.model';
import { EuropaService } from '../services/europa.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ComentarioComponent } from '../comentario/comentario.component';

@Component({
  selector: 'app-spain',
  standalone: true,
  imports: [CommonModule, FormsModule, ComentarioComponent],
  templateUrl: './spain.component.html',
  styleUrl: './spain.component.css'
})
export class SpainComponent implements OnInit{
  spain$ = new Observable<pais>()
  comentario: string = ''
  mostrar: boolean = false
  constructor(private service : EuropaService){}
  ngOnInit( ): void {
    this.spain$ = this.service.getSpain();
    console.log(this.spain$)
  }
  mostrarComentario(){
    this.mostrar = true
  }
}
