<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../styles/commonStyles.css">
    <link rel="stylesheet" href="../inputs/inputsStyles.css">
    <title>Cerveceria Juan</title>
</head>
<body>
    <?php 
    session_start();
    include '../inputs/header.php'?>
    <main>
        <h1>Home</h1>
    </main>
    <?php include '../inputs/footer.php'?>
</body>
</html>