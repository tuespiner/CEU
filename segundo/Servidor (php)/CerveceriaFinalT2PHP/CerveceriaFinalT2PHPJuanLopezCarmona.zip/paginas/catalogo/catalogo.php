<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../styles/commonStyles.css">
    <link rel="stylesheet" href="../inputs/inputsStyles.css">
    <link rel="stylesheet" href="../../styles/catalogoStyle.css">
    <title>Cerveceria Juan</title>
</head>
<body>
    <?php
    session_start(); 
    $_SESSION['donde'] = 'catalogo';
    include '../consultas/consultarProducto.php';
    include '../inputs/header.php';
    $_SESSION['productos'] = getProductos();
    if(!isset($_SESSION['posicionVerMas'])){
        $_SESSION['posicionVerMas'] =[];
    }
    if (isset($_GET['posicionVerMas'])) {
        include 'includeVerMas.php';
    }
    if(isset($_GET['anadirCerveza'])){
        anadirProducto();
        header('Location: catalogo.php');
    }
    if(isset($_GET['cerveza'])){
        modificarProducto();
        header('Location: catalogo.php');
    }
    if(isset($_GET['modificar'])){
        cambiarModoModificar($_GET['modificar']);
        header('Location: catalogo.php');
    }
    if(isset($_GET['eliminar'])){
        eliminarCerveza($_GET['eliminar']);
        header('Location: catalogo.php');
    }
    ?>
    <main>
        <h2>CATÁLOGO</h2>
        <?php
        if($_SESSION['productos'] != null){
            include 'imprimirCatalogo.php';
        }else{
            echo "<h2>No hay productos en la base de datos</h2>";
        }
        if($_SESSION['usuario']['perfil'] == "admin"){
            echo '<a class="anadirCerveza" href="catalogo.php?anadirCerveza=1">AÑADIR CERVEZA</a>';
        }
        ?>
    </main>
    <?php include '../inputs/footer.php'?>
</body>
</html> 