<?php
if(in_array($_GET['posicionVerMas'], $_SESSION['posicionVerMas'])){
    $arrayNuevo = [];
    foreach($_SESSION['posicionVerMas'] as $posicion){
        if($posicion != $_GET['posicionVerMas']){
            array_push($arrayNuevo, $posicion);
        }
    }
    $_SESSION['posicionVerMas'] = $arrayNuevo;
}else{
    array_push($_SESSION['posicionVerMas'], $_GET['posicionVerMas']);
}
header('Location: catalogo.php');?>