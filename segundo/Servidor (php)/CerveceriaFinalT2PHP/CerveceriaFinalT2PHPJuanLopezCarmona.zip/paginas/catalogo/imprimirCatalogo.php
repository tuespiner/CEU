<?php
    $posicion = 0;
    $verMas = 'VER MÁS';
    $imprimirVerMas = '';
    while ($fila = $_SESSION['productos']->fetch_assoc()){
        $posicion++;
        if($_SESSION['usuario']['perfil'] == 'admin' && $fila['modificar'] == 1){
            echo '<form method="post" action="catalogo.php?cerveza='.$fila['id'].'">';
            echo '<div class="imagen"><label for="foto">fotoEjemplo.jpg</label><input type="text" name="foto" id="foto" ></div>';
            echo '<div><ul><li><label for="formato">Formato</label><input type="text" name="formato" id="formato" value="'.$fila['formato'].'"></li>';
            echo '<li><label for="marca">Marca</label><input type="text" name="marca" id="marca" value="'.$fila['marca'].'"></li>';

            if($fila['formato'] != ' '){
                $opcionSeleccionada = substr($fila['tipo'], -1);
                $tipo = array_fill(0,4,'');
                $tipo[intval($opcionSeleccionada) - 1] = 'selected'; 
            }
            echo '<li><label for="tipo">Tipo</label><select name="tipo" id="tipo">';
            echo '<option '.$tipo[0].' value="botellin1">botellin</option>';
            echo '<option '.$tipo[1].' value="tercio2">lata</option>';
            echo '<option '.$tipo[2].' value="botella3">botella</option>';
            echo '<option '.$tipo[3].' value="barril4">Barril</option>';
            echo '</select></li>';

            echo '<li><label for="tamano">Tamaño</label><input type="text" name="tamano" id="tamano" value="'.$fila['tamano'].'"></li>';
            echo '<li><label for="precio">Precio</label><input type="number" name="precio" id="precio" value="'.$fila['precio'].'">€</li>';
            if($fila['denominacion'] != ' '){
                $opcionSeleccionada = substr($fila['denominacion'], -1);
                $denominacion = array_fill(0,16,'');
                $denominacion[intval($opcionSeleccionada) - 1 ]  = 'selected';
            }
            echo '<li><label for="denominacion">Denominacion</label><select name="denominacion" id="denominacion">';
            echo '<option '.$denominacion[0].' value="Lager1">Lager</option>';
            echo '<option '.$denominacion[1].' value="PaleLager2">Pale Lager</option>';
            echo '<option '.$denominacion[2].' value="Marzen3">Marzen</option>';
            echo '<option '.$denominacion[3].' value="Bock4">Bock</option>';
            echo '<option '.$denominacion[4].' value="AmericanLager5">American Lager</option>';
            echo '<option '.$denominacion[5].' value="Ale6">Ale</option>';
            echo '<option '.$denominacion[6].' value="PaleAle7">Pale Ale</option>';
            echo '<option '.$denominacion[7].' value="IPA8">IPA</option>';
            echo '<option '.$denominacion[8].' value="Bitter9">Bitter</option>';
            echo '<option '.$denominacion[9].' value="BrownAle10">Brown Ale</option>';
            echo '<option '.$denominacion[10].' value="Poter11">Poter</option>';
            echo '<option '.$denominacion[11].' value="Stout12">Sotut</option>';
            echo '<option '.$denominacion[12].' value="Trapenses13">Trapenses</option>';
            echo '<option '.$denominacion[13].' value="Abadia14">Abadia</option>';
            echo '<option '.$denominacion[14].' value="Weisbier15">Weisbier</option>';
            echo '<option '.$denominacion[15].' value="Witbier16">Witbier</option>';
            echo '</select></li>';

            echo '<li><label for="fecha">Fecha Consumo(yyyy-mm-dd)</label><input type="text" name="fecha" id="fecha" value="'.$fila['fecha_consumo'].'"></li>';
            echo '<li><label for="observacion">Observaciones</label><textarea name="observacion" id="observacion" value="'.$fila['observaciones'].'"></textarea></li>';
            echo '<li><label for="alergias">Alergenos</label><div>';
            
            echo '<p><input type="checkbox" name="alergenos[]" id="alergias" value="Gluten">Gluten</p>';
            echo '<p><input type="checkbox" name="alergenos[]" id="alergias" value="Huevo">Huevo</p>';
            echo '<p><input type="checkbox" name="alergenos[]" id="alergias" value="Cacahuete">Cacahuete</p>';
            echo '<p><input type="checkbox" name="alergenos[]" id="alergias" value="Soja">Soja</p>';
            echo '<p><input type="checkbox" name="alergenos[]" id="alergias" value="Lacteo">Lacteo</p>';
            echo '<p><input type="checkbox" name="alergenos[]" id="alergias" value="Sulfitos">Sulfitos</p>';
            echo '<p><input type="checkbox" name="alergenos[]" id="alergias" value="frutosCascara">Frutos Con Cascara</p>';
            echo '<p><input type="checkbox" name="alergenos[]" id="alergias" value="noAlergenos">Sin Alergenos</p>';

            echo '</div></li></ul>';
            echo '<div class="enlaces">';
            echo '<input type="submit" value="GUARDAR">';
            echo '<a href="catalogo.php?eliminar='.$fila['id'].'">ELIMINAR</a>';
            echo '</div></div></form>';
        }else if($fila['modificar'] == 0){
            echo '<div class="producto">';
            echo '<div class="imagen"><img src="'.$fila['foto'].'"></div>';
            echo '<div><h3>'.strtoupper($fila['formato']).'</h3>';
            echo '<ul><li><p><span>Marca:</span> '.$fila['marca'].'</p></li>';
            echo '<li><p><span>Tipo:</span> '.substr($fila['tipo'], 0, -1).'</p></li>';
            echo '<li><p><span>Tamaño:</span> '.$fila['tamano'].'</p></li>';
            echo '<li><p><span>Precio:</span> '.$fila['precio'].'€</p></li>';
            echo ($_SESSION['donde'] == 'catalogo'? '' : '<li><p><span>Cantidad:</span>'.$_SESSION['arrayCantidad'][$fila['id']].
            '<a href="../carrito/carrito.php?add='.$fila['id'].'"> + </a><a href="../carrito/carrito.php?reduce='.$fila['id'].'"> - </a></p></li></ul>');
            if(isset($_SESSION['posicionVerMas']) && in_array($posicion, $_SESSION['posicionVerMas'])){
                $verMas = 'VER MENOS';
                $imprimirVerMas = '<ul><li><p><span>Denominacion: </span>'.substr($fila['denominacion'], 0, -1).'</p></li>'.
                '<li><p><span>Fecha Consumo: </span>'.$fila['fecha_consumo'].'</p></li>'.
                '<li><p><span>Observaciones: </span>'.$fila['observaciones'].'</p></li>'.
                '<li><p><span>Alergias: </span>'.$fila['alergias'].'</p></li></ul>';
            }else{
                $verMas = 'VER MAS';
                $imprimirVerMas = '';
            }
            print $imprimirVerMas;
            echo '<div class="enlaces">';
            if($_SESSION['usuario']['perfil'] == 'usuario'){
                echo '<a href="'.($_SESSION['donde'] == 'catalogo'? '../carrito/carrito.php?add=' : '../carrito/carrito.php?quitar=').$fila['id'].'">'.
                ($_SESSION['donde'] == 'catalogo'? 'AÑADIR AL CARRITO' : 'QUITAR DEL CARRITO').'</a>';
            }elseif($_SESSION['donde'] == 'catalogo'){
                echo '<a href="catalogo.php?modificar='.$fila['id'].'">MODIFICAR</a>';
            }
            echo '<a href="'.($_SESSION['donde'] == 'catalogo'? 'catalogo.php?' : '../carrito/carrito.php?').'posicionVerMas='.$posicion.'">'.$verMas.'</a></div></div></div>';
        }
    }
?>