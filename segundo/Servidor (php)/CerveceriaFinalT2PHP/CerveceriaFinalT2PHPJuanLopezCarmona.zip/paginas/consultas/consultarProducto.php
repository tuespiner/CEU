<?php
include_once 'conexion.php';

function consulta($query){
    global $conn;
    if(str_starts_with($query, "INSERT")){
        $sql = $conn->prepare($query);
        if($sql->execute()){
            echo "funsiona";
        }else{
            echo "No funciona";
        }
        $sql->close();
    }else{
        $resultado = $conn->query($query);
        if(str_starts_with($query, "SELECT") && $resultado->num_rows == 0){
            $resultado = null;
        }else{
            return $resultado;
        }
    }
        
}

function getProductos(){
    $query = "SELECT * FROM producto";
    $resultado = consulta($query);
    if ($resultado->num_rows > 0) {
        return $resultado;
    } else {
        return null;
    }
}

function anadirProducto(){
    $query = "INSERT INTO `producto`(`denominacion`, `formato`, `tamano`, `tipo`,".
    " `precio`, `marca`, `fecha_consumo`, `alergias`, `foto`, `observaciones`, `modificar`)".
    " VALUES (' ',' ',' ',' ','0',' ','2027-1-1',' ',' ',' ','1')";
    consulta($query);
}
function modificarProducto(){
    $alergias = '';
    if(isset($_REQUEST['alergenos'])){
        echo 'entreeeeee';
        foreach($_REQUEST['alergenos'] as $alergia){
            $alergias = $alergias.$alergia." ";
        }
    }
    echo $alergias.'jfdsklafjd;lksafjlk;adsjflk;dsaflk;djsl;fkjds';
    $query = "UPDATE `producto` SET `denominacion`='".$_REQUEST['denominacion']."',`formato`='".$_REQUEST['formato']."',`tamano`='".$_REQUEST['tamano']."'".
    ",`tipo`='".$_REQUEST['tipo']."',`precio`='".$_REQUEST['precio']."',`marca`='".$_REQUEST['marca']."',`fecha_consumo`='".$_REQUEST['fecha']."',".
    "`alergias`='".(($alergias == '')? 'Sin alergias' : $alergias)."',".
    "`foto`='../../imagenes/bbdd/".trim($_REQUEST['foto'])."',`observaciones`='".$_REQUEST['observacion']."',`modificar`='0' WHERE `producto`.`id` = ".$_REQUEST['cerveza'];
    consulta($query);
}

function cambiarModoModificar($id){
    $query = "UPDATE `producto` SET `modificar` = '1' WHERE `producto`.`id` = ".$id;
    consulta($query);
}
function eliminarCerveza($id){
    $query = "DELETE FROM `producto` WHERE `producto`.`id` = ".$id;
    consulta($query);
}

function getCarrito($carrito){
    $query = "SELECT * FROM producto WHERE ";
    foreach($carrito->productosCarrito as $producto){
        $query = $query.' producto.id = '.$producto->id.' or';
        $_SESSION['arrayCantidad'][$producto->id] = $producto->cant;
    }
    $query = substr($query, 0, -3);
    return consulta($query);
}
function actualizarCarrito($carrito,$idProducto,$crud){
    $eliminar = false;
    $esta = false;
    foreach($carrito->productosCarrito as $producto){
        if($crud = 'eliminar'){
            $eliminar = true;
        }else if($producto->id == $idProducto && $crud == 'add'){
            $producto->cant = $producto->cant + 1;
            echo $producto->cant;
        }else if($producto->id == $idProducto){
            if($producto->cant <= 1){
                $eliminar == true;
            }else{
                $producto->cant = $producto->cant - 1;
            }
        }

        if($producto->id == $idProducto){
            $esta = true;
        }
    }
    if($eliminar){
        $carrito->productosCarrito = array_filter($carrito->productosCarrito, function($producto){
            return $producto->id !== $idProducto;
        });
    }
    if(!$esta){
        array_push($carrito->productosCarrito,(object) ["id" => $idProducto, "cant" => 1]);
    }
    $query = "UPDATE `usuario` SET `carrito` = '".json_encode($carrito)."' WHERE `usuario`.`id` = ".$_SESSION['usuario']['id'];
    consulta($query);
}
?>