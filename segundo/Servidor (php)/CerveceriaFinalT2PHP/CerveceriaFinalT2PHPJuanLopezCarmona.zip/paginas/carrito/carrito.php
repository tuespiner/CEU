<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../styles/commonStyles.css">
    <link rel="stylesheet" href="../inputs/inputsStyles.css">
    <title>Document</title>
</head>
<body>
    <?php
        session_start();
        $_SESSION['donde'] = 'carrito';
        include '../consultas/consultarProducto.php';
        include '../inputs/header.php';
        $carrito = json_decode($_SESSION['usuario']['carrito']);
        $_SESSION['arrayCantidad'] = [];
        $_SESSION['productos'] = getCarrito($carrito);
        ?>
    <main>
        <?php
            if (isset($_GET['add'])) {
                actualizarCarrito($carrito, $_GET['add'],'add');
                header('Location: ../carrito/carrito.php');
            }
            if (isset($_GET['reduce'])) {
                actualizarCarrito($carrito, $_GET['reduce'],'reduce');
                header('Location: ../carrito/carrito.php');
            }

            if(empty($carrito->productosCarrito)){
                echo '<p>No hay productos en el carrito</p>';
            }else{
                include '../catalogo/imprimirCatalogo.php';
            }  
        ?>
    </main>
    <?php include '../inputs/footer.php';?>
</body>
</html>