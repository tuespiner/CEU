#   COLORES
## ¿Qué colores has elegido?

    Los colores que he elegido son:

- <span style="color:#000; background-color:#fff;border-radius:10px; padding:0.25rem 4rem 0.25rem 0.25rem ;font-weight:bold;">Blanco: #fff</span>

- <span style="color:#000; background-color:#61b9ad;border-radius:10px; padding:0.25rem 4rem 0.25rem 0.25rem ;font-weight:bold;magin-top:1rem;">Verde agua: #61b9ad</span>

- <span style="color:#000; background-color:#e9aec4;border-radius:10px; padding:0.25rem 4rem 0.25rem 0.25rem ;font-weight:bold;magin-top:1rem;">Rosa pastel: #e9aec4</span>

- <span style="color:#000; background-color:#5d302d;border-radius:10px; padding:0.25rem 4rem 0.25rem 0.25rem ;font-weight:bold;magin-top:1rem;">Marrón: #5d302d</span>

## ¿Porqué has elegido esos colores?
    -Los colores no tienen ningun significado especial, alomejor como son colores pasteles dan la impresión de ser una pasteleria o algun sitio  "dulce".

    -El verdadero motivo de porque he elegido esos colores es por que el logo del bar los tiene.

    Además en el propio bar ves los colores en las mesas, las sillas, las paredes, etcetera.

### Imágen del logo del bar
<img src="Imágenes/1959359722-1.webp" style="border-radius: 25%;width:300px;">