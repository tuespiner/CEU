const subir = document.getElementById("subir")
subir.addEventListener("click", () =>{
    location.hash = "#inicio"
})