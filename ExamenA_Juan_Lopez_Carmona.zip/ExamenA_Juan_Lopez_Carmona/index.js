var objArr = [{id: 1, estado: "abierta", asunto: "no enciende", descripcion: "no funciona", detalles: {priodidad: "alta", usuario: "juan"}},
    {id: 2, estado: "abierta", asunto: "internet", descripcion: "no funciona", detalles: {priodidad: "alta", usuario: "lucas"}},
    {id: 3, estado: "cerrada", asunto: "incidencia", descripcion: "funciona", detalles: {priodidad: "alta", usuario: "ana"}},
    {id: 4, estado: "cerrada", asunto: "incidencia", descripcion: "funciona", detalles: {priodidad: "baja", usuario: "juan"}},
    {id: 5, estado: "pendiente", asunto: "incidencia", descripcion: "no funciona", detalles: {priodidad: "alta", usuario: "juan"}},
    {id: 6, estado: "pendiente", asunto: "no enciende", descripcion: "no funciona", detalles: {priodidad: "media", usuario: "pablo"}},
    {id: 7, estado: "abierta", asunto: "internet", descripcion: "no funciona", detalles: {prioridad: "media", usuario: "belen"}},
    {id: 8, estado: "abierta", asunto: "internet", descripcion: "no funciona", detalles: {priodidad: "alta", usuario: "belen"}}]

window.addEventListener("DOMContentLoaded", () =>{
    var resultado = document.getElementById("resultado");
    var boton = document.getElementById("searchButton")
    boton.addEventListener("click", () =>{
        var listaResultado = [];
        var id = document.getElementById("searchId").value
        var asunto = document.getElementById("searchAsunto").value
        var descripcion = document.getElementById("searchDescripcion").value
        var estado = document.getElementById("searchEstado")

        function porId(){
            objArr.forEach((elemento) =>{
                if(elemento.id == id){
                    listaResultado.push(elemento)
                }
            })
            console.log(listaResultado)
        }
        function porAsunto(){
            objArr.forEach((elemento) =>{
                if(elemento.asunto.indexOf(asunto) != -1){
                    listaResultado.push(elemento)
                }
            })
            console.log(listaResultado)
        }
        function porDescripcion(){
            objArr.forEach((elemento) =>{
                if(elemento.asunto.indexOf(descripcion) != -1){
                    listaResultado.push(elemento)
                }
            })
            console.log(listaResultado)
        }

        //comprovaciones del filtrado
        

        function crearThead(){
            var thead = document.createElement("thead")
            var tr = document.createElement("tr")
            var thId = document.createElement("th")
            thId.textContent = "ID"
            var thEstado = document.createElement("th")
            thEstado.textContent = "Estado"
            var thAsunto = document.createElement("th")
            thAsunto.textContent = "Asunto"
            var thPrioridad = document.createElement("th")
            thPrioridad.textContent = "Prioridad"
            var thAcciones = document.createElement("th")
            thAcciones.textContent = "Acciones"
            tr.appendChild(thId)
            tr.appendChild(thEstado)
            tr.appendChild(thAsunto)
            tr.appendChild(thPrioridad)
            tr.appendChild(thAcciones)
            thead.appendChild(tr)
            return thead
        }
        function crearTbody(){
            var tbody = document.createElement("tbody")
            listaResultado.forEach((element) =>{
                var tr = document.createElement("tr")
                var tdId = document.createElement("td")
                tdId.textContent = element.id
                var tdEstado = document.createElement("td")
                tdEstado.textContent = element.estado
                var tdAsunto = document.createElement("td")
                tdAsunto.textContent = element.asunto
                var tdPrioridad = document.createElement("td")
                tdPrioridad.textContent = element.detalles.prioridad
                var tdAcciones = document.createElement("td")
                tr.appendChild(tdId)
                tr.appendChild(tdEstado)
                tr.appendChild(tdAsunto)
                tr.appendChild(tdPrioridad)
                tr.appendChild(tdAcciones)
                console.log(tr)
                tbody.appendChild(tr)
            })
            return tbody
        }
        function crearTabla(){
            if(document.getElementsByTagName("table").length > 0){
                var tabla = document.getElementsByTagName("table")[0]
                tabla.childNodes[0].remove()
                tabla.childNodes[0].remove()
                var thead = crearThead();
                var tbody = crearTbody();
                tabla.appendChild(thead)
                tabla.appendChild(tbody)
            }else{
                var tabla = document.createElement("table")
                var thead = crearThead();
                var tbody = crearTbody();
                tabla.appendChild(thead)
                tabla.appendChild(tbody)
                resultado.appendChild(tabla)
            }
        }
        console.log("id "+id+" asunto "+asunto.length+" descripcion "+descripcion.length)
        if(id.length > 0 && asunto.length > 0 && descripcion.length > 0){
            objArr.forEach((elemento) =>{
                if(elemento.id == id && elemento.asunto.indexOf(asunto) != -1 && elemento.descripcion.indexOf(descripcion) != -1){
                    listaResultado.push(elemento)
                }
            })
            crearTabla()
        }else if(id.length > 0  && asunto.length > 0){
            objArr.forEach((elemento) =>{
                if(elemento.id == id && elemento.asunto.indexOf(asunto) != -1){
                    listaResultado.push(elemento)
                }
            })
            crearTabla()

        }else if(id.length > 0 && descripcion.length > 0){
            objArr.forEach((elemento) =>{
                if(elemento.id == id && elemento.descripcion.indexOf(descripcion) != -1){
                    listaResultado.push(elemento)
                }
            })
            crearTabla()
        }else if(descripcion != "" && asunto.length > 0){
            objArr.forEach((elemento) =>{
                if(elemento.asunto.indexOf(asunto) != -1 && elemento.descripcion.indexOf(descripcion) != -1){
                    listaResultado.push(elemento)
                }
            })
            crearTabla()
        }else if(id.length > 0){
            objArr.forEach((elemento) =>{
                if(elemento.id == id ){
                    listaResultado.push(elemento)
                }
            })
            crearTabla()
        }else if(asunto.length > 0){
            objArr.forEach((elemento) =>{
                if(elemento.asunto.indexOf(asunto) != -1){
                    listaResultado.push(elemento)
                }
            })
            crearTabla()
        }else if(descripcion.length > 0){
            objArr.forEach((elemento) =>{
                if(elemento.descripcion.indexOf(descripcion) != -1){
                    listaResultado.push(elemento)
                }
            })
            crearTabla()
        }else{
            alert("No hay datos que concuerden con el filrado")
        }
        
    })
})