window.addEventListener("DOMContentLoaded", () =>{
    var boton = document.getElementById("enviarButton")
    boton.addEventListener("click", (e) =>{
        e.preventDefault();
        var nombre = document.getElementById("nombre").value
        var nombreErr;
        var correo = document.getElementById("correo").value
        var correoErr;
        var fechaNacimiento = document.getElementById("fechaNacimiento").value
        var fechaNacimientoErr;
        var contraseña = document.getElementById("contraseña").value
        var contraseñaErr;
        var errorMensage = document.getElementById("errorMessage")
        var sorpresa = document.getElementById("quieroSorpresa")
        var noSorpresa = document.getElementById("noQuieroSorpresa")

        function crearError(motivo, dato){
            let p = document.createElement("p")
            p.className = "errorMessage"
            if(motivo == "Vacío"){
                if(dato != "fecha de nacimiento" && dato != "contraseña"){
                    p.textContent = `El ${dato} no puede estar vacío`
                }else{
                    p.textContent = `La ${dato} no puede estar vacío`
                }
            }else if(motivo == "@"){
                p.textContent = `El correo debe contener @`
            }else if(motivo == "contraseñaLength"){
                p.textContent = `La contraseña debe tener al menos 8 caracteres`
            }else if(motivo == "Edad"){
                p.textContent = `Tienes que ser mayor de edad`
            }
            return p;

        }
        function mayorEdad(fecha){
            var fechaArr = fecha.split("-")
            var fechaIntro = new Date(fechaArr[0], fechaArr[1], fechaArr[2]);
            var fecha = new Date();
            fecha = new Date(fecha - fechaIntro)
            if((fecha.getFullYear() - 1970 ) <18){
                return false
            }else{
                return true
            }
            
        }
        var lengthChildren = errorMensage.childNodes;
        for(let i = 0; lengthChildren.length > 0; i++){
            lengthChildren[i].remove();
        }

        if(nombre == ""){
            nombreErr = crearError("Vacío", "nombre")
            console.log(nombreErr)
            errorMensage.appendChild(nombreErr)
        }
        if(correo == ""){
            correoErr = crearError("Vacío", "correo")
            console.log(correoErr)
            errorMensage.appendChild(correoErr)
        }else if(correo.indexOf("@") == -1){
            correoErr = crearError("@", "correo")
            console.log(correoErr)
            errorMensage.appendChild(correoErr)
        }
        if(fechaNacimiento == ""){
            fechaNacimientoErr = crearError("Vacío", "fecha de nacimiento")
            console.log(fechaNacimientoErr)
            errorMensage.appendChild(fechaNacimientoErr)
        }else if(!mayorEdad(fechaNacimiento)){
            fechaNacimientoErr = crearError("Edad", "fecha de nacimiento")
            console.log(fechaNacimientoErr)
            errorMensage.appendChild(fechaNacimientoErr)
        }
        if(contraseña == ""){
            contraseñaErr = crearError("Vacío", "contraseña")
            console.log(contraseñaErr)
            errorMensage.appendChild(contraseñaErr)
        }else if(contraseña.length < 8){
            contraseñaErr = crearError("contraseñaLength", "contraseña")
            console.log(contraseñaErr)
            errorMensage.appendChild(contraseñaErr)
        }
        console.log(nombreErr + " "+ correoErr + " "+ fechaNacimientoErr + " "+ contraseñaErr )
        if(nombreErr == undefined && correoErr == undefined && fechaNacimientoErr == undefined && contraseñaErr == undefined){
            document.getElementById("sorpresa").style.display = "block"
        }else{
            document.getElementById("sorpresa").style.display = "none"
        }
        
        sorpresa.addEventListener("click", () =>{
            var random = Math.floor(Math.random() * (2 - 0 + 1 ))
            var sorpresaId = document.getElementById("sorpresaId")
            var img = document.createElement("img")
            img.style.width = "650px"
            img.style.height = "350px"
            if(random == 1){
                img.src = "sorpresa1.jpg"
            }else{
                img.src = "sorpresa2.jpg"
            }
            sorpresaId.appendChild(img)
        })

        noSorpresa.addEventListener("click", () =>{
            var timer = setTimeout(() =>{
                var sorpresaId = document.getElementById("sorpresaId")
                var img = document.createElement("img")
                img.src = "sorpresaNO.jpg"
                sorpresaId.appendChild(img)
            },3000)
        })

    })
})